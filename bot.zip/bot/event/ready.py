from donnees.start import *
import discord

@bot.event
async def on_ready():
    ################################################################################################
    ################################################################################################
    #                                            LOG
    ################################################################################################
    ################################################################################################
    print(bot.user.name,"est connecté")
    print(bot.user.id)
    print('------')
    print(" ")
    print(" ")
    print("bot.py")
    
    ################################################################################################
    ################################################################################################
    #                                         File Embed
    ################################################################################################
    ################################################################################################

    fichier = open('C:/Users/.../msg.txt', 'r')     ## #message embed
    msg = fichier.read()
    fichier.close
    fichier = open('C:/Users/.../title.txt', 'r')   ## #title embed
    title = fichier.read()
    fichier.close
    gui = bot.get_guild(id_guild)                   ##
    channel_rule = gui.get_channel(id_channel_embed)   ##
    newEmbed = discord.Embed(
    title = str(title),                             #title (title.txt)
    description= str(msg),                          #message (message.txt)
    colour = discord.Colour.dark_red()              #color embed
    )
    #await channel_rule.send( embed = newEmbed)     # for first embed
    messages = await channel_rule.history(limit=1).flatten()
    message = await bot.get_channel(id_channel_embed).fetch_message(id_embed)
    await message.edit(embed = newEmbed)
    await message.add_reaction('<:nom_emoji:id_emoji>')
    await message.add_reaction('<:nom_emoji:id_emoji>')
    await message.add_reaction('<:nom_emoji:id_emoji>')
    await message.add_reaction('<:nom_emoji:id_emoji>')