from donnees.start import *

@bot.event
async def on_raw_reaction_add(payload):
    gui = bot.get_guild(payload.guild_id)
    mem = gui.get_member(payload.user_id)
    if str(payload.emoji) == '<:nom_emoji:id_emoji>':   ##
        role = mem.guild.get_role(role_id)              ##
        await mem.add_roles(role)
    if str(payload.emoji) == '<:nom_emoji:id_emoji>':   ##
        role = mem.guild.get_role(role_id)              ##
        await mem.add_roles(role)
    if str(payload.emoji) == '<:nom_emoji:id_emoji>':   ##
        role = mem.guild.get_role(role_id)              ##
        await mem.add_roles(role)
    if str(payload.emoji) == '<:nom_emoji:id_emoji>':   ##
        role = mem.guild.get_role(role_id)              ##
        await mem.add_roles(role)