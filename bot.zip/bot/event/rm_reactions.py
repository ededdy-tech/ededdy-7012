from donnees.start import *

@bot.event
async def on_raw_reaction_remove(payload):
    gui = bot.get_guild(payload.guild_id)
    mem = gui.get_member(payload.user_id)
    if payload.message_id == id_message_embed :             ##
        if str(payload.emoji) == '<:nom_emoji:id_emoji>':   ##
            role = mem.guild.get_role(id_emoji)             ##
            await mem.remove_roles(role)
        if str(payload.emoji) == '<:nom_emoji:id_emoji>':   ##
            role = mem.guild.get_role(id_emoji)             ##
            await mem.remove_roles(role)
        if str(payload.emoji) == '<:nom_emoji:id_emoji>':   ##
            role = mem.guild.get_role(id_emoji)             ##
            await mem.remove_roles(role)
        if str(payload.emoji) == '<:nom_emoji:id_emoji>':   ##
            role = mem.guild.get_role(id_emoji)             ##
            await mem.remove_roles(role)