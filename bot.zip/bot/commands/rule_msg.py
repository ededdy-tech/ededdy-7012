from donnees.start import *
import os

@bot.command()
async def rule_msg(ctx, *, arg):
    if ctx.author.guild_permissions.manage_guild == True :
        fichier = open('C:/Users/.../msg', 'w')     ##
        fichier.write(str(arg))
        fichier.close