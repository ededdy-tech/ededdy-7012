from donnees.start import *
import discord


@bot.command()
async def help(ctx):    #help_messgae
    msg = '''
    **{}clear** [**n**] {clear **n** messages}

    **{}help** {affiche ce message}

    **{}rule_actu** {actualise l'**embed welcome-rule**}

    **{}rule_msg** [**text**] {modifie le text de l'**embed**}

    **{}rule_title** [**text**] {modifie le titre de l'**embed**}
    '''
    embed = discord.Embed(
    title = '**Help**',                     #title embed
    description = msg,                      #message embed
    colour = discord.Colour.dark_gold()     #color embed
    )
    embed.set_thumbnail(url=bot.user.avatar_url)
    await ctx.channel.send(embed=embed)