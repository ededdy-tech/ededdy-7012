from donnees.start import *

@bot.command()
async def clear(ctx, arg):
    if ctx.author.guild_permissions.manage_guild == True :
        arg = int(arg)
        await ctx.channel.purge(limit=arg+1)