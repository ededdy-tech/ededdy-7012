from donnees.start import *
import os, discord

#actualisation embed

@bot.command()
async def rule_actu(ctx):
    if ctx.author.guild_permissions.manage_guild == True :
        fichier = open('C:/Users/.../msg', 'r')         ##
        msg = fichier.read()
        fichier.close
        fichier = open('C:/Users/.../title', 'r')       ##
        title = fichier.read()
        fichier.close
        gui = bot.get_guild(guild_id)                       ##
        channel_rule = gui.get_channel(id_channel_embed)    ##
        embed = discord.Embed(
        title = str(title),
        description= str(msg),
        colour = discord.Colour.dark_red()  #color embed
        )
        message = await bot.get_channel(id_channel_embed).fetch_message(id_message_embed)  ##
        await message.edit(embed = embed)