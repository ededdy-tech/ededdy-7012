from discord.ext import commands

token = "bot_token"     ##

choix = None #(None or True) ##
bot = commands.Bot(command_prefix='prefix(example:'-')', help_command = choix) ##