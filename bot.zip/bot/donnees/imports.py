from discord.ext import commands
import discord, os

from event.ready import *
from event.reactions import *
from event.rm_reactions import *

from commands.rule_msg import *
from commands.rule_title import *
from commands.rule_actu import *
from commands.clear import *
from commands.help import *


from donnees.start import *